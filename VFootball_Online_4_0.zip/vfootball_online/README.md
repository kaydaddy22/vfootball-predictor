# V-Football Predictor 4.0

Free Streamlit app for screenshot-to-odds analysis of Football.com Instant Virtuals England.

## Deploy on Streamlit Community Cloud

1. Create a **public** GitHub repository named `vfootball-predictor`.
2. Upload `app.py`, `requirements.txt`, and `packages.txt` to the repository root.
3. Sign in at https://share.streamlit.io/ with GitHub.
4. Click **Create app**, choose the repository and branch `main`, and set the main file to `app.py`.
5. Click **Deploy**. Open the generated Streamlit URL on your phone.

## Use

Upload the three market screenshots together, click **Read screenshots**, review all odds in the editor, and click **Apply reviewed odds**. Full Round Analysis then refreshes.

OCR may fail to recognize some lines; do not assume unrecognized odds are correct. Predictions are odds-derived and have not been validated as profitable. This app does not scrape Football.com or automatically retrieve results. Free hosting may reset sessions.
